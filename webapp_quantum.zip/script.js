const ATOMIC_TRAITS = {
    Entity_Faces: [
        "Synthetic Sovereign", "Cybernetic Guardian", "Quantum Muse", "Silicon Sentinel", 
        "Celestial Construct", "Neural Empress", "Holographic Arbiter", "Post-human Entity",
        "Data-stream Node", "Glitch Titan", "Techno-Core", "Bio-mechanical Prime", 
        "Titanium Valkyrie", "Void-Walker Unit", "Omniscient Neural Hub"
    ],
    Entity_Abstract: [
        "Quantum singularity", "Neural entropy swarm", "Fractal energy core", "Data-stream vortex",
        "Liquid light explosion", "Cosmic binary nebula", "Geometric transcendence", "Plasma silk sculpture",
        "Ethereal data ghost", "Techno-organic constellation", "Supernova glitch", "Holographic supernova"
    ],
    Archetypes: [
        "Cybernetic God", "Quantum Goddess", "Techno-Hero", "Neon-Heroine",
        "Bio-mechanical Deity", "Celestial Warrior", "Ascended Neural Entity", "Silicon Titan"
    ],
    Body_Elements: [
        "full-body heroic stance", "levitating divine silhouette", "armored warrior physique",
        "statuesque deity proportions", "ethereal robes of liquid silk", "exoskeleton of pulsing fiber-optics",
        "nano-composite tactical armor", "flowing digital energy-wings", "mantle of rotating geometric halos",
        "crystalline spinal column visible through back", "limbs of translucent celestial plasma"
    ],
    Facial_Base: [
        "sculpted porcelain face", "translucent bio-engineered skin", "shifting liquid mercury visage",
        "matte obsidian composite features", "iridescent synth-flesh", "matte white carbon fiber",
        "humanoid face of brushed titanium", "perfectly symmetrical synthetic skin", "veined marble cyber-face",
        "molten glass skin with internal glow", "pearl-textured neural composite", "black-hole obsidian features"
    ],
    Circuitry_Integration: [
        "subsurface golden circuitry pulsing with warm light", "glowing neon neural pathways",
        "intricate fiber-optic capillaries", "micro-laser etched fractal patterns",
        "embedded crystalline processors along the jawline", "liquid light conduits flowing like tears",
        "ultraviolet data-sigils glowing beneath the surface", "active nanite swarms forming temporary scars",
        "hexagonal nanite plating pulsing at 60Hz", "superconducting emerald ley-lines"
    ],
    Materials_Abstract: [
        "iridescent bismuth crystals", "molten rainbow chrome", "frozen dark matter shards",
        "translucent jelly-like cosmic plasma", "layered sheets of digital silk", "interlocking geometric prisms",
        "swirling vapor of electrified mercury", "shattered diamond aerosols", "glowing neon thread lattices"
    ],
    Ocular_Augmentation: [
        "multi-faceted diamond ocular lenses", "glowing sapphire optic sensors",
        "void-black sensory implants with rotating rings", "burning amber laser-array eyes",
        "liquid nitrogen cooled ocular chambers", "holographic iris projecting status codes",
        "mechanical pupils contracting with clockwork precision", "eyeless facial structure with sensor-nodes",
        "star-chart projection lenses", "vortex-iris reflecting distant galaxies"
    ],
    Energy_FX: [
        "vortex of swirling quantum energy particles", "ethereal wisps of plasma energy",
        "cascading binary code rain", "halos of rotating geometric light",
        "molecular dust particles suspended in a temporal field", "aurora-like data streams",
        "pulsing ion-fields creating a corona effect", "shimmering heat-distortion from over-clocked cores",
        "electromagnetic lightning arcs", "floating glyphs of ancient neural code",
        "high-voltage plasma arcs", "nebulous ionized clouds", "pulsing electrical storms", "interstellar nebula wisps"
    ],
    Style_Artist: [
        "H.R. Giger organic-tech bio-mechanical", 
        "Moebius surreal sci-fi line-art",
        "Syd Mead industrial futurism aesthetic",
        "Beeple digital chaos and complexity",
        "Zdzisław Beksiński dystopian nightmare",
        "Peter Mohrbacher celestial entity horror",
        "Alberto Seveso high-speed liquid dynamic",
        "Android Jones psychedelic digital visionary",
        "James Thompson cyber-renaissance detail"
    ],
    Lighting_Atmosphere: [
        "volumetric fog, 8k neon flares", "dense digital haze, light-streaks",
        "crystalline snow falling upwards, zero-g", "chromatic aberration, event horizon",
        "subtle glitch-art distortions", "bokeh of data-shards and hexagons",
        "dramatically backlit by a dying blue giant", "cinematic rain reflecting emerald neon",
        "biological luminescence", "quantum entanglement lighting, spooky action at a distance",
        "nebular cosmic glow", "electric storm backlighting", "strobe lighting, ion discharges",
        "dramatic chiaroscuro neon highlights", "ethereal plasma rim-lighting"
    ],
    Color_Theory: [
        "cyberpunk cyan and electric magenta", "toxic green and deep ultraviolet",
        "regal gold and matte black", "iridescent opal and midnight blue",
        "crimson pulse and metallic chrome", "blood orange and cold steel gray",
        "monochromatic silver and neon white", "retro-vaporwave pastel gradients",
        "electric blue and violet nebula", "plasma white and ionized cyan",
        "anodized copper and electric cobalt"
    ]
};

let currentPlatform = 'midjourney';
let currentMode = 'FACES';

// DOM Elements
const tabBtns = document.querySelectorAll('.tab-btn');
const modeBtns = document.querySelectorAll('.mode-btn');
const generateBtn = document.getElementById('generate-btn');
const promptOutput = document.getElementById('prompt-output');
const copyBtn = document.getElementById('copy-btn');
const tipMidjourney = document.getElementById('tips-midjourney');
const tipLeonardo = document.getElementById('tips-leonardo');

// State Management
tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentPlatform = btn.dataset.platform;
        
        // Toggle Tips
        if(currentPlatform === 'midjourney') {
            tipMidjourney.classList.add('active');
            tipLeonardo.classList.remove('active');
        } else {
            tipMidjourney.classList.remove('active');
            tipLeonardo.classList.add('active');
        }
    });
});

modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        modeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentMode = btn.dataset.mode;
    });
});

// Randomizer helper
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

// Generators
function generateMidjourney(mode) {
    const style = pick(ATOMIC_TRAITS.Style_Artist);
    const colors = pick(ATOMIC_TRAITS.Color_Theory);
    const energy = pick(ATOMIC_TRAITS.Energy_FX);
    const lighting = pick(ATOMIC_TRAITS.Lighting_Atmosphere);
    
    let core;
    let ar = '--ar 4:5';

    if (mode === 'FACES') {
        const entity = pick(ATOMIC_TRAITS.Entity_Faces);
        const base = pick(ATOMIC_TRAITS.Facial_Base);
        const circuits = pick(ATOMIC_TRAITS.Circuitry_Integration);
        const eyes = pick(ATOMIC_TRAITS.Ocular_Augmentation);
        core = `Portrait of a ${entity}, ${base}, ${circuits}, ${eyes}, ${energy}, ${lighting}, ${colors}, style by ${style}`;
    } else if (mode === 'FULLBODY') {
        const arch = pick(ATOMIC_TRAITS.Archetypes);
        const body = pick(ATOMIC_TRAITS.Body_Elements);
        const circuits = pick(ATOMIC_TRAITS.Circuitry_Integration);
        core = `Full body cinematic shot of a ${arch}, ${body}, ${circuits}, ${energy} integration, ${lighting}, ${colors}, epic scale, style by ${style}`;
        ar = '--ar 9:16';
    } else {
        const entity = pick(ATOMIC_TRAITS.Entity_Abstract);
        const material = pick(ATOMIC_TRAITS.Materials_Abstract);
        core = `Conceptual abstract art: ${entity}, made of ${material}, ${energy}, ${lighting}, ${colors}, inspired by ${style}`;
        ar = '--ar 16:9';
    }

    return `${core}, intricate details, hyper-realistic, 8k --v 6.0 ${ar} --stylize 750`;
}

function generateLeonardo(mode) {
    const style = pick(ATOMIC_TRAITS.Style_Artist);
    const colors = pick(ATOMIC_TRAITS.Color_Theory);
    const energy = pick(ATOMIC_TRAITS.Energy_FX);
    const lighting = pick(ATOMIC_TRAITS.Lighting_Atmosphere);
    
    if (mode === 'FACES') {
        const entity = pick(ATOMIC_TRAITS.Entity_Faces);
        const base = pick(ATOMIC_TRAITS.Facial_Base);
        const circuits = pick(ATOMIC_TRAITS.Circuitry_Integration);
        const eyes = pick(ATOMIC_TRAITS.Ocular_Augmentation);
        return `Masterpiece cinematic portrait of ${entity}. Features: ${base}, ${circuits}, ${eyes}. Surrounded by ${energy}. Atmospheric ${lighting}. Color palette: ${colors}. Art style of ${style}. Global illumination, raytracing, highly detailed textures.`;
    } else if (mode === 'FULLBODY') {
        const arch = pick(ATOMIC_TRAITS.Archetypes);
        const body = pick(ATOMIC_TRAITS.Body_Elements);
        const circuits = pick(ATOMIC_TRAITS.Circuitry_Integration);
        return `Epic full body visualization of a ${arch}. Detailed ${body}, ${circuits} glowing throughout anatomy. Integrated with ${energy}. Dramatic ${lighting}. Dynamic colors: ${colors}. Aesthetic of ${style}. Cinematic lighting, 8k depth of field.`;
    } else {
        const entity = pick(ATOMIC_TRAITS.Entity_Abstract);
        const material = pick(ATOMIC_TRAITS.Materials_Abstract);
        return `Stunning abstract visualization: ${entity} constructed from ${material}. Swirling ${energy}. ${lighting} effects. ${colors} theme. In the style of ${style}. Complex geometry, sharp focus, 8k detail.`;
    }
}

// Action
generateBtn.addEventListener('click', () => {
    // Animation effect
    promptOutput.style.opacity = '0';
    
    setTimeout(() => {
        let result;
        if(currentPlatform === 'midjourney') {
            result = generateMidjourney(currentMode);
        } else {
            result = generateLeonardo(currentMode);
        }
        
        promptOutput.innerText = result;
        promptOutput.style.opacity = '1';
    }, 200);
});

// Copy Functionality
copyBtn.addEventListener('click', () => {
    const text = promptOutput.innerText;
    if(text.includes('Haz clic')) return;

    navigator.clipboard.writeText(text).then(() => {
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = '¡COPIADO!';
        copyBtn.style.background = '#00f2ff';
        copyBtn.style.color = '#000';
        
        setTimeout(() => {
            copyBtn.innerHTML = originalText;
            copyBtn.style.background = '';
            copyBtn.style.color = '';
        }, 1500);
    });
});
